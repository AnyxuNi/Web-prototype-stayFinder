STAYFINDER PORTABLE FINAL BUILD

This build is designed for sharing to another XAMPP computer without manually creating/importing the MySQL database.

FIRST-TIME SETUP
1. Install XAMPP with Apache and MySQL/MariaDB.
2. Copy the project folder to C:\xampp\htdocs\renthome\.
3. Start Apache and MySQL in XAMPP.
4. Open http://localhost/renthome/setup.php
5. The system automatically creates renthome_db and all required tables/columns.
6. Create the administrator account on the setup page.
7. Log in through http://localhost/renthome/login.php
8. After setup, delete or rename setup.php for extra security.

EXISTING STAYFINDER DATABASE
If renthome_db already exists, the bootstrap preserves existing data and adds missing tables/columns required by the current build. It does not intentionally delete existing records.

IMPORTANT
- XAMPP MySQL/MariaDB must be running.
- The default XAMPP root password is assumed to be blank. If your MySQL root account has a password, edit config/database.php.
- Uploaded property images, permit files, and payment proofs are files, not database records. Copy the uploads/ folder together with the project.
- Existing database records are not packaged into this ZIP. The ZIP contains the database structure, not your current users/listings.
- For a demonstration computer, create an admin account through setup.php and register test users/listings as needed.
